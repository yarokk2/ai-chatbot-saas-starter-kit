import { NextRequest, NextResponse } from "next/server";
import { streamText } from "ai";
import { openai } from "@ai-sdk/openai";
import { checkRateLimit } from "@/lib/rate-limit";
import { createAuditLog } from "@/lib/audit-log";

export async function POST(request: NextRequest) {
  const forwardedFor =
    request.headers.get("x-forwarded-for") ?? "anonymous";

  const identifier = forwardedFor.split(",")[0].trim();


  try {
      const { success, limit, remaining, reset } =
          await checkRateLimit(identifier);

        if (!success) {
          return new Response(
            JSON.stringify({
              error: "Rate limit exceeded",
              message:
                "You have reached your daily message limit. Please upgrade your plan or try again later.",
              limit,
              remaining,
              reset,
            }),
            {
              status: 429,
              headers: {
                "Content-Type": "application/json",
                "X-RateLimit-Limit": String(limit),
                "X-RateLimit-Remaining": String(remaining),
                "X-RateLimit-Reset": String(reset),
              },
            }
          );
        }
    const { message } = await request.json();
    await createAuditLog({
      action: "chat.message_sent",
      metadata: {
        messageLength:
          typeof message === "string" ? message.length : 0,
        identifier,
        model: "gpt-5-mini",
      },
    });

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey || apiKey === "demo_key_not_used") {
      return NextResponse.json({
        message: [
          "# AI Demo Response",
          "",
          "This is a markdown response.",
          "",
          "## TypeScript Example",
          "",
          "```ts",
          "interface User {",
          "  id: string;",
          "  name: string;",
          "}",
          "",
          'const user: User = {',
          '  id: "1",',
          '  name: "Yaroslav",',
          "};",
          "",
          "console.log(user);",
          "```",
          "",
          "## Features",
          "",
          "- Markdown rendering",
          "- Code blocks",
          "- Lists",
          "- Tables",
        ].join("\n"),
      });
    }


    // Demo mode:


    const result = streamText({
      model: openai("gpt-4o-mini"),
      messages: [
        {
          role: "user",
          content: message,
        },
      ],
    });

    return result.toTextStreamResponse();
  } catch (error) {
    console.error("Chat API Error:", error);

    return NextResponse.json(
      {
        message:
          error instanceof Error
            ? error.message
            : "An error occurred while processing your request.",
      },
      {
        status: 500,
      }
    );
  }
}